from banking_pkg import account
def atm_menu(name):
    print("")
    print("          === Automated Teller Machine ===          ")
    print("User: " + name)
    print("------------------------------------------")
    print("| 1.    Balance     | 2.    Deposit      |")
    print("------------------------------------------")
    print("------------------------------------------")
    print("| 3.    Withdraw    | 4.    Logout       |")
    print("------------------------------------------")
    
while True:

    print("          === Automated Teller Machine ===          \n")
    name = input("Enter your name to register: ")
    print("The maximum name length is 10characters\n")

    if len(name) > 10:
        print("Please enter a valid number of characters\n")
    elif len(name) == 0:
        print("You must enter a name\n")
    else:
        break
while True:

    pin = input("Please Enter a 4 digit PIN: ")
    if len(pin) > 4:
        print("You entered an invalid number\n")
    elif len(pin) < 4:
        print("You entered and invalid number\n")
    else:
        break
    

balance = 0.0
print(name.capitalize() + " has been registered with starting balance of $"+str(balance))
print(" ")

while True:
    print('LOGIN')
    name_to_validate = input("Enter Name: ")
    pin_to_validate = input("Enter PIN: ")

    if name == name_to_validate and pin == pin_to_validate:
        print("Login Successful")
        break
    else:
        print("Invalid Credentials!!\n\n")

while True:
    atm_menu(name)
    option = input("Choose an option: ")
    if option == '1':
        account.show_balance(balance)
    elif option == '2':
        balance = account.deposit(balance)
    elif option == '3':
        balance = account.withdraw(balance)
    elif option == '4':
        account.logout(name)
        break
    else:
        print("Wrong option!\n\n")